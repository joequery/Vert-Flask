//Joseph McCullough
//Program: capEachWord.cpp
//Description: Takes a string and capitalizes each word of the string.
//Visit www.mcculloughdesigns.com/blog for more C++ Goods!

#include <iostream>
#include <string>
using namespace std;

void lowerCase(string&);
void capEachWord(string&);

const string SENTINEL = "0";//When entered as strToConvert, 
							//terminates program.

int main()
{
	string strToConvert;  //The string that will be converted.

	cout << "***********************************" << "\n"
		 << "CapEachWord.exe"                     << "\n"
		 << "Capitalizes every word in a string." << "\n"
		 << "Provided By McCullough Designs"      << "\n"
		 << "***********************************";

	//Read in strToConvert
	cout << "\n\nEnter a String or enter 0 to exit: ";
	getline(cin, strToConvert);

	while (strToConvert != SENTINEL)
	{
		capEachWord(strToConvert);
		cout << "\nNew String: " << strToConvert;

		//Read in strToConvert
		cout << "\n\nEnter a String or enter 0 to exit: ";
		getline(cin, strToConvert);

	}
	return 0;
}


/****** function capEachWord *****
Description: converts the first letter of a word to a capital letter

PARAMETERS
	strToConvert: the string being manipulated

Precondition:
	strToConvert: undefined

	HEADERS
	#include <string> 

Postcondition:
	Returns the string with the first letter of every word capitalized.  */

void capEachWord(string& strToConvert)
{
	//Turn all letters lowercase
	lowerCase(strToConvert);

	for (unsigned int i=0; i<strToConvert.length();i++)
	{
		// If current character is alphabetical
		// AND
		// (If current character is the first letter of the string
		// OR
		// The character before was a blank space
		// OR a punctuation mark.)
		// Capitalize the character.
		if (isalpha(strToConvert[i]) && 
		((i==0) || 
		((ispunct(strToConvert[i-1]) ||
		(isspace(strToConvert[i-1]))))))

		strToConvert[i]=toupper(strToConvert[i]);

	}

}


/****** function lowerCase *****
Description: makes all the characters of a string lowercase

PARAMETERS
	strToConvert: the string being manipulated

Precondition:
	strToConvert: undefined

	HEADERS
	#include <string> 

Postcondition:
	Returns the string all lowercase */

void lowerCase(string& strToConvert) 
{
   for(unsigned int i=0;i<strToConvert.length();i++)
   {
      strToConvert[i] = tolower(strToConvert[i]);
   }
}

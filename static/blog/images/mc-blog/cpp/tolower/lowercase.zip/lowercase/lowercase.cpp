// Name: Joseph McCullough
// Program: tolower
// Description: Turns a string to lowercase. 
// Visit www.mcculloughdesigns.com/blog for more c++ tutorials!
// Feel free to use this code for whatever: Work, fun, cheating on homework. 

#include <string>
#include <iostream>

using namespace std;
void lowerCase(string&);

const string SENTINEL = "0"; //Used to terminate program. 

int main()
{
	string userInput;        //What the user will enter to lowercase.
	
	cout << "\n**********************************\n"
		 << "Convert your strings to lowercase." 
		 << "\nProvided by McCullough Designs"
		 << "\n**********************************\n\n";
		 
	cout << "\n\nEnter the string you wish to lowercase or 0 to quit: ";
	getline(cin, userInput);

	while (userInput != SENTINEL)
	{
	
		lowerCase(userInput);
		cout << "\nResult: " << userInput << "\n";

		cout << "\nEnter the string you wish to lowercase or 0 to quit: ";
		getline(cin, userInput);

	
	}

	cout << "\n\nProgram terminated by User.\n";

	return 0;

}

/****** function lowerCase *****
Description: makes all the characters of a string lowercase

PARAMETERS
	strToConvert: the string being manipulated

Precondition:
	strToConvert: undefined

	HEADERS
	#include <string> 

Postcondition:
	Returns the string all lowercase */

void lowerCase(string& strToConvert) 
{
   for(unsigned int i=0;i<strToConvert.length();i++)
   {
      strToConvert[i] = tolower(strToConvert[i]);
   }
}